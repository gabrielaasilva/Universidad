
/**
 * Write a description of class Xook here.
 * 
 * @author (your name) 
 * 
 * @version (a version number or a date)
 */
import java.util.*;


public class Xook{
    private static int numero;
    private int n;
    private int m;
    private Circle[] circ;    
    private Rectangle[] rect;
    private int xPosition;
    private int yPosition;
    private boolean isVisible;
    

    /**
     * Constructor for objects of class Xook
     */
    public Xook(int numero)
    {
        
        this.numero = numero;
        operacion();
        xPosition = 25;
        yPosition = 20;
        isVisible = false;
        // initialise instance variables
        
    }
    
    public void setValue(int nuevoNumero){
       numero = nuevoNumero;
       operacion();

    }
    
    public int getValue(){
        return numero;
    
    }
    
    public void makeVisible(){
        draw_circle();
        draw_rectangle();
        isVisible = true;
    }
    public void makeInvisible(){
        erase(); 
        isVisible = false;
    }
    
    private void  erase(){
        
       for(int i= 0;i<n;i++){
            circ[i].makeInvisible();
        }    
            
       for(int i= 0;i<m;i++){        
            rect[i].makeInvisible();
        }     
               
       numero = 0;
    }    
    private void draw_circle(){
        circ = new Circle[n];
        for(int i= 0;i<n;i++){
            circ[i] = new Circle();
            circ[i].makeVisible();
            circ[i].moveHorizontal(xPosition);
            if (n==1){
            circ[i].moveHorizontal(30);
        }
           if(n==2){
           circ[i].moveHorizontal(23);
        }
           if(n==3){
           circ[i].moveHorizontal(10);
        }
           if(n==4){
           circ[i].moveHorizontal(3);
        }
            xPosition+= 20;
        }
        
        xPosition = 25;
        if(isVisible == true){
            makeInvisible();
        }
    }
    
    private void draw_rectangle(){
        rect = new Rectangle[m];
        for(int i= 0;i<m;i++){
            rect[i] = new Rectangle();
            rect[i].makeVisible();
            rect[i].moveVertical(yPosition);
            yPosition+= 15;
    
        } 
        yPosition = 20;
         if(isVisible == true){
            makeInvisible();
        }
    }
    private void operacion(){
        n = numero%5;
        m = (int)numero/5;
    }
    public void changeColor(String newColor){
        for (int i=0; i<n;i++){
            circ[i].changeColor(newColor);
    }
        for (int i=0; i<m;i++){
            rect[i].changeColor(newColor);
    }   
    }
    
    public void moveHorizontal(int distance){
        for (int i=0; i<n;i++){
            circ[i].moveHorizontal(distance);
    }
        for (int i=0; i<m;i++){
            rect[i].moveHorizontal(distance);
    }   
        
    }
    public void random(){
        Random random = new Random();
        numero = random.nextInt(19);
        operacion();
    }
}