package edu.eci.arsw.gof.chainofrep.loanapproval.model;

import java.text.ParseException;
import java.util.Calendar;

public class Request extends AutomatedLoanEvaluator{
	
	@Override
	public boolean  isApplicationDeclined(ApplicationDetails application,String[] outcome) throws ParseException {
	       int curYear = Calendar.getInstance().get(Calendar.YEAR);
	        String dobYear = application.getDob();
	        int age = curYear - Integer.parseInt(dobYear.substring(0, 4));

	        if (age > 65 || age < 18) {
	        	outcome[0]="Too young or too old";
	            return true;
	        }

	        int WorkExp = application.getWork_Ex_Year() * 12 + application.getWork_Ex_Mon();

	        if (WorkExp < 6) {
	        	outcome[0]="Too little working experience";
	            return true;
	        }

	        if (application.getAnn_Sal() < 10000) {
	        	outcome[0]="Too little income";
	            return true;
	        }	
	        
	        if(application.getMarital_Status() == "Married" && application.getAnn_Sal() < 20000) {
	        	outcome[0] = "Married and too little income";
	        	return true;
	        }
		return false;
	} 
}
