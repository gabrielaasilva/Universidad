package edu.eci.arsw.gof.chainofrep.loanapproval.model;
import static org.junit.Assert.*;

import java.text.ParseException;

import org.junit.Test;

public class AutomatedTesting {
	
	@Test
	public void esMuyJoven() {
		AutomatedLoanEvaluator request = new Request();
        ApplicationDetails ad = new ApplicationDetails("John", "", "Connor", "2020-01-01",
                "Single", "11101", 0, "Home Improvement Loan", "742 de Evergreen Terrace", 
                "", "Springfield", "CA", 0, 0, 0, 0, "john123@hotmail.com", 
                "Loan description", "IBM", 30000, 10, 2, 
                "Officer", "342 SouthLake Av", "", "Yorktown", 
                "VA", 3242323);
        String[] outCome = new String[1];
        try {
			assertEquals(request.isApplicationDeclined(ad,outCome), true);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void esMuyViejo() {
		AutomatedLoanEvaluator request = new Request();
        ApplicationDetails ad = new ApplicationDetails("John", "", "Connor", "1900-01-01",
                "Single", "11101", 0, "Home Improvement Loan", "742 de Evergreen Terrace", 
                "", "Springfield", "CA", 0, 0, 0, 0, "john123@hotmail.com", 
                "Loan description", "IBM", 30000, 10, 2, 
                "Officer", "342 SouthLake Av", "", "Yorktown", 
                "VA", 3242323);
        String[] outCome = new String[1];
        try {
			assertEquals(request.isApplicationDeclined(ad,outCome), true);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void faltaExperiencia() {
		AutomatedLoanEvaluator request = new Request();
        ApplicationDetails ad = new ApplicationDetails("John", "", "Connor", "1995-01-01",
                "Single", "11101", 0, "Home Improvement Loan", "742 de Evergreen Terrace", 
                "", "Springfield", "CA", 0, 0, 0, 0, "john123@hotmail.com", 
                "Loan description", "IBM", 30000, 0, 0, 
                "Officer", "342 SouthLake Av", "", "Yorktown", 
                "VA", 3242323);
        Request rq = new Request();
        String[] outCome = new String[1];
        try {
			assertEquals(request.isApplicationDeclined(ad,outCome), true);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void salarioInsuficiente() {
		AutomatedLoanEvaluator request = new Request();
        ApplicationDetails ad = new ApplicationDetails("John", "", "Connor", "1995-01-01",
                "Single", "11101", 0, "Home Improvement Loan", "742 de Evergreen Terrace", 
                "", "Springfield", "CA", 0, 0, 0, 0, "john123@hotmail.com", 
                "Loan description", "IBM", 30000, 1, 2, 
                "Officer", "342 SouthLake Av", "", "Yorktown", 
                "VA", 3242323);
        String[] outCome = new String[1];
        Request rq = new Request();
        ad.setAnn_Sal(9000);
        try {
			assertEquals(request.isApplicationDeclined(ad,outCome), true);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void score() {
		AutomatedLoanEvaluator ale = new Score();
        ApplicationDetails ad = new ApplicationDetails("John", "", "Connor", "1980-01-01",
                "Single", "11101", 0, "Home Improvement Loan", "742 de Evergreen Terrace", 
                "", "Springfield", "CA", 0, 0, 0, 0, "john123@hotmail.com", 
                "Loan description", "IBM", 30000, 10, 2, 
                "Officer", "342 SouthLake Av", "", "Yorktown", 
                "VA", 3242323);
        assertNotSame(ale.getScore(ad), 285.645);
	}
	
	@Test
	public void married() {
		AutomatedLoanEvaluator request = new Request();
        ApplicationDetails ad = new ApplicationDetails("John", "", "Connor", "1980-01-01",
                "Married", "11101", 0, "Home Improvement Loan", "742 de Evergreen Terrace", 
                "", "Springfield", "CA", 0, 0, 0, 0, "john123@hotmail.com", 
                "Loan description", "IBM", 17000, 10, 2, 
                "Officer", "342 SouthLake Av", "", "Yorktown", 
                "VA", 3242323);
        String[] outCome = new String[1];
        try {
			assertEquals(request.isApplicationDeclined(ad,outCome), true);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
