------------------------------------TuplasOK------------------------------------

insert into Registro values (10,20,TO_DATE('2020-01-01','YYYY/MM/DD'),40,'V',60,15);
insert into Participante values ('dcc','151515154648269','andrea@gmail.com','COLOMBIA',TO_DATE('2020-01-01','YYYY/MM/DD'), null);
insert into Actividad values (10,TO_DATE('2019-11-05','YYYY/MM/DD'),1459,50,140,'foto.jpg');
insert into Atleta('dcc','189215154648269','kmgaskrea@gmail.com','COLOMBIA',TO_DATE('2020-01-01','YYYY/MM/DD'),TO_DATE('2020-02-01','YYYY/MM/DD'),'+','O');
insert into SimirA values (15,16,50);

