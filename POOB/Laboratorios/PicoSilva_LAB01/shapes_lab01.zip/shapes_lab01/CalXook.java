
/**
 * Write a description of class CalXook here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CalXook {
    // instance variables - replace the example below with your own
    private int n1;
    private int n2;
    public int res;
    private String operacion;
   

    /**
     * Constructor for objects of class CalXook
     */
    public CalXook(int n1,int n2, String operacion)
    {
        // initialise instance variables
        this.n1 = n1;
        this.n2 = n2;
        res = 0;
        this.operacion = operacion; 
        
    }
   
    public int showResult(){
        return res;
        
    }

    public class Suma extends CalXook{
        int suma;
        
        public Suma (int n1, int n2){
            super(n1,n2,"+");
            res=n1+n2;
            
        }
    }   
    
    public class Resta extends CalXook{
        int resta;
        
        public Resta(int n1, int n2){
            super(n1,n2,"-");
            this.resta = n1-n2;
            this.res = this.resta;
        
        }
    }
    
    public class Multiplicacion extends CalXook{
        int multi;
        
        public Multiplicacion (int n1, int n2){
            super(n1,n2,"*");
            this.multi = (n1*n2);
            this.res = this.multi;
        
        }
    
    }
    
    public class Division extends CalXook{
    
        int div = 0;
        
        public Division(int n1,int n2){
            super (n1, n2, "/");
            if (n2 == 0){ 
            System.out.println("No se puede realizar");
        }
            else{ 
                this.div = n1/n2;
            this.res = this.div;
        }
        }
            
    }
} 


