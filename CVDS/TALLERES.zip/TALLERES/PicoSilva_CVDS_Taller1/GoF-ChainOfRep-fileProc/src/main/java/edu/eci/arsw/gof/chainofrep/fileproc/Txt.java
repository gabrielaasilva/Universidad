package edu.eci.arsw.gof.chainofrep.fileproc;
import java.util.logging.Logger;

public class Txt extends Procesos {
    private static final Logger LOG = Logger.getLogger(DataProcessor.class.getName());
	@Override
	public void EjecutarProceso() {
        LOG.info("Processing TXT...");
	}
}
