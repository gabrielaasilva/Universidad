package edu.eci.arsw.gof.chainofrep.fileproc;

public class Procesos {
	
	public void EjecutarProceso() {
		System.out.println("no existe ese tipo");
	}
}

