/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.eci.arsw.gof.chainofrep.fileproc;

import java.util.logging.Logger;
import org.apache.commons.io.FilenameUtils;

/**
 *
 * @author hcadavid
 */


public class DataProcessor{
	private Procesos procesos;
	
    public void loadAndProcessData(String fileName) throws DataLoadException{
        
        LOG.info("Loading data...");
        
        
        if (extension(fileName).equals("xml")){
        	procesos = new Xml();
        	procesos.EjecutarProceso();
        }
        else if (extension(fileName).equals("csv")){
        	procesos = new Cvs();
			procesos.EjecutarProceso();                
        }
        else if (extension(fileName).equals("json")){
            procesos = new Json();
            procesos.EjecutarProceso();              
        }
        else if (extension(fileName).equals("txt")){
        	procesos = new Txt();
        	procesos.EjecutarProceso();
        }
        else{
            throw new DataLoadException("Format not supported:"+extension(fileName));
        }
        
        /*
            DATA PROCESSING CORE
        */
        LOG.info("Processing data...");
        LOG.info("Done. Execution finished.");
    }
    
    public String extension(String fileName){
        return FilenameUtils.getExtension(fileName);
    }
    
    private static final Logger LOG = Logger.getLogger(DataProcessor.class.getName());
    


}


