package edu.eci.arsw.gof.chainofrep.loanapproval.model;

public class Score extends AutomatedLoanEvaluator {
	   @Override
	   public double getScore(ApplicationDetails ap) {
	        String purp = ap.getLoan_Purpose();
	        double p;

	        double loaninc_ratio = (ap.getLoan_Amount()) / (ap.getAnn_Sal());
	        if (purp.equalsIgnoreCase("Car Loan")) {
	            p = 0.838;
	        } else if (purp.equalsIgnoreCase("Credit Card")) {
	            p = 0.877;
	        } else if (purp.equalsIgnoreCase("Debt Consolidation")) {
	            p = 0.831;
	        } else if (purp.equalsIgnoreCase("Educational Loan")) {
	            p = 0.810;
	        } else if (purp.equalsIgnoreCase("Home Improvement Loan")) {
	            p = 0.850;
	        } else if (purp.equalsIgnoreCase("House Loan")) {
	            p = 0.819;
	        } else {
	            p = 0.815;
	        }

	        double x = -0.30720295 - (2.42709152 * loaninc_ratio) - (1.61109691 * 0.01 * ap.getWork_Ex_Year())+p*0.212 ;
	        double probability = 1 / (1 + Math.exp(-1 * x));
	        double score = probability * 666.67;
	        return score;
	    }
}
