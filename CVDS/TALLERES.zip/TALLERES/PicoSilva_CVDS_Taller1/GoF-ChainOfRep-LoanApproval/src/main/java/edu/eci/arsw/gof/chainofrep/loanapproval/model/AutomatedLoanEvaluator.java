/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.eci.arsw.gof.chainofrep.loanapproval.model;

import java.text.ParseException;
import java.util.Calendar;

/**
 *
 * @author hcadavid
 */
public class AutomatedLoanEvaluator {
	public boolean isApplicationDeclined(ApplicationDetails application,String[] outcome) throws ParseException {
		return false;
	}
	
	 public double getScore(ApplicationDetails ap) {
		 return 0;
	 }
}
