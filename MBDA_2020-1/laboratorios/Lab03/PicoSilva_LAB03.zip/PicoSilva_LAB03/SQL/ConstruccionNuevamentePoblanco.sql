-- insercion uno

 insert into Evaluacion(numeroE,fecha ,puntaje,comentarios,recomendaciones,numero,tidE,nidE) values (15,TO_DATE('2019-11-04','YYYY/MM/DD'),4,'Muy suave',9,'dcc','519933645173605');
 insert into Actividad (numero,fechaInicio,horaInicio,timepoTotal,pulsacionesProm,fotos) values(9,TO_DATE('2019-11-03','YYYY/MM/DD'),800,50,2.5,'foto.jpg');
 insert into Evaluacion(numeroE,fecha ,puntaje,comentarios,recomendaciones,numero,tidE,nidE) values (16,TO_DATE('2019-11-06','YYYY/MM/DD'),3,'Muy fuerte', 10,'dcc','517360201234513');
 insert into Actividad (numero,fechaInicio,horaInicio,timepoTotal,pulsacionesProm,fotos) values (10,TO_DATE('2019-11-05','YYYY/MM/DD'),1459,50,2.2,'foto.jpg');
 insert into similarA((numero1, numero2, porcentaje) values (15,16,50);
 