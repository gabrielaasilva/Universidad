import java.util.*;
/**
 * Fraccionario
 * Esta clase implementa el tipo de dato Fraccionario; es decir, un n�mero racional que se pueden escribir de la forma p/q, donde p y q son enteros, con q <> 0
 * La implemantacion se hace mediante objetos inmutables
 * INV: El fraccionario se encuentra representado en forma irreductible.
 * @author E.C.I.
 *
 */
public class Fraccionario {
    private static ArrayList<Integer> lista1;
    private static ArrayList<Integer> lista2; 
    private static ArrayList<Integer> lista3;
    private static ArrayList <Integer> fraction;
    /**Calcula el maximo comun divisor de dos enteros
     * Lo implementaremos mediante el algoritmo recursivo
     * @param a primer entero
     * @param b segundo entero
     * @return el Maximo Comun Divisor de a y b
     */

    public static int mcd(int a,int b){
        lista1 = new ArrayList();
        lista2 = new ArrayList();
        a = Math.abs(a);
        b = Math.abs(b);
        for (int i=2 ; i<=a;i++){
            while(a%i==0){
                lista1.add(i);
                a = a/i;
            }
        }
        for (int j=2 ; j<=b;j++){
            while(b%j==0){
                lista2.add(j);
                b = b/j;
            }
        }
        return comparacionLista(lista1,lista2);        
    }

    /**Crea un nuevo fraccionario, dado el numerador y el denominador
     * @param numerador
     * @param denominador. denominador <> 0
     */
    public Fraccionario (int numerador, int denominador) {
        fraction = new ArrayList();
        fraction.add(numerador);
        fraction.add(denominador);
        this.fraction = simplificar(fraction);
        convertirNegativo(fraction);
    }

    /**Crea un fraccionario correspondiente a un entero
     * @param entero el entero a crear
     */
    public Fraccionario (int entero) {
        fraction = new ArrayList();
        fraction.add(entero);
        fraction.add(1);
    }

    /**Crea un fraccionario, a partir de su representacion mixta. 
     * El numero creado es enteroMixto + numeradorMixto/denominadorMixto
     * @param enteroMixto la parte entera del numero
     * @param numeradorMixto el numerador de la parte fraccionaria
     * @param denominadorMixto el denominador de la parte fraccionaria. denominadorMixto<>0
     */
    public Fraccionario (int enteroMixto, int numeradorMixto, int denominadorMixto) {

    }

    /**
     * Un fraccionario p/q esta escrito en forma simplificada si q es un entero positivo y 
     * el maximo comun divisor de p y q es 1.
     * @return El numerador simplificado del fraccionario
     */
    public int numerador() {
        return fraction.get(0);
    }

    /**
     * Un fraccionario p/q esta escrito en forma simplificada si q es un entero Positivo y 
     * el maximo comun divisor de p y q es 1.
     * @return el denominador simplificado del fraccionario
     */
    public int denominador() {
        return fraction.get(1);
    }

    /**Suma este fraccionario con otro fraccionario
     * @param otro es otro fraccionario
     * @return este+otro
     */
    public static Fraccionario sume (Fraccionario otro) {
        int numerador1;
        numerador1 = (fraction.get(0)*otro.denominador())+(fraction.get(1)*otro.numerador());
        int denominador1;
        denominador1 = fraction.get(1)*otro.denominador();
        Fraccionario res = new Fraccionario(numerador1,denominador1);
        return (res);
    }

    public static Fraccionario reste (Fraccionario otro) {
        int numerador1;
        numerador1 = (fraction.get(0)*otro.denominador())-(fraction.get(1)*otro.numerador());
        int denominador1;
        denominador1 = fraction.get(1)*otro.denominador();
        Fraccionario res = new Fraccionario(numerador1,denominador1);
        return (res);
    }

    /**Multiplica este fraccionario con otro fraccionario
     * @param otro El otro fraccionario
     * @return este * otro
     */
    public Fraccionario multiplique (Fraccionario otro) {
        int numerador1;
        numerador1 = (fraction.get(0)*otro.numerador());
        int denominador1;       
        denominador1 = (fraction.get(1)*otro.denominador());
        Fraccionario res = new Fraccionario(numerador1,denominador1);
        return res;
    }

    /**Divide este fraccionario sobre otro fraccionario
     * @param otro El otro fraccionario
     * @return este * otro
     */
    public Fraccionario divida (Fraccionario otro) {
        return null;
    }

    @Override
    public boolean equals(Object obj) {
        return equals((Fraccionario)obj);
    }    

    /**Compara este fraccionario con otro fraccionario
     * @param otro eL otro fraccionario
     * @return true si este fraccionario es igual matem�ticamente al otro fraccionario, False d.l.c.
     */
    public boolean equals (Fraccionario otro) {
        if (otro.numerador()==0 && fraction.get(0)==0){
            return true;
        }
        if (otro.numerador() == fraction.get(0) && otro.denominador() == fraction.get(1)){
            return true;
        }
        else{
            return false;
        }
    }

    /** Calcula la representacion en cadena de un fraccionario en formato mixto simplificado
     * @see java.lang.Object#toString(java.lang.Object)
     */
    @Override
    public String toString() {
        return fraction.get(0)+"/"+fraction.get(1);
    }

    /**Compara los divisores de cada numero guardados en listas 
     * @param lista1 primer ArrayList de enteros
     * @param lista2 segundo ArrayList de enteros
     * @return entero
     */
    private static int comparacionLista(ArrayList<Integer> lista1,ArrayList<Integer> lista2){  
        lista3 = new ArrayList();
        if(lista1.size() < lista2.size()){
            for (int k = 0;k<lista1.size();k++){
                if(lista2.contains(lista1.get(k))){
                    lista3.add(lista1.get(k));
                }
            }
        }
        else{
            for (int k = 0;k<lista2.size();k++){
                if(lista1.contains(lista2.get(k))){
                    lista3.add(lista2.get(k));
                }
            }
        }
        return multiplicacionLista(lista3);
    }  

    /**Realiza la multiplicación de los elementos de una Lista
     * @param lista3 primer ArrayList de enteros 
     * @return entero 
     */
    private static int multiplicacionLista(ArrayList<Integer> lista3){
        int res = 1;
        for (int i=0; i < lista3.size();i++){
            res*=lista3.get(i);
        }
        return res;
    }

    /**Permite simplificar un fraccionario
     * @param lista primer ArrayList de enteros 
     * @return lista
     */
    private ArrayList<Integer> simplificar(ArrayList<Integer> lista){
        int x = mcd(lista.get(0),lista.get(1));

        lista.set(0,lista.get(0)/x);
        lista.set(1,lista.get(1)/x);
        return lista; 

    }

    /**convirte un fraccioanrio negativo a positivo 
     * @param lista primer ArrayList de enteros
     */
    private void convertirNegativo(ArrayList<Integer> lista){
        if(lista.get(1)<0){
            lista.set(0, -1*lista.get(0));
            lista.set(1, -1*lista.get(1));
        }
    }

}
