
/**
 * Crear simulacion de juego de Damas.
 *
 * @author (Juan Andrés Pico & Ana Gabriela Silva )
 * 
 */
import java.util.Scanner;
import java.util.HashMap;
import javax.swing.JOptionPane;
public class Checkers
{
    // instance variables - replace the example below with your own
    private int width ;
    private int fila;
    private int columna;
    private int numero;
    private int Xposition;
    private int Yposition;
    private boolean itsOk = true;
    private String colorUno;
    private String colorDos;
    private String tipo;
    private int [][] matrix=

        {{0,1,0,1,0,1,0,1},
            {1,0,1,0,1,0,1,0},
            {0,1,0,1,0,1,0,1},
            {1,0,1,0,1,0,1,0},
            {0,1,0,1,0,1,0,1},
            {1,0,1,0,1,0,1,0},
            {0,1,0,1,0,1,0,1},
            {1,0,1,0,1,0,1,0}};
    private Rectangle[][] tablero;
    private Circle[][] jugadorUno;
    private Circle[][] jugadorDos;
    private Juego confi;
    private Juego juego;

    /**
     * Constructor for objects of class Checkers
     */
    public Checkers()
    {
        // initialise instance variables

        this.width = width;
        int Yposition = 0;
        this.Yposition = Yposition;
        this.Xposition = Xposition;
        confi = new Juego(0);
        juego = new Juego(250);
        jugadorUno = new Circle[8][8];
        jugadorDos = new Circle[8][8];
    }

    public void add (boolean king,int row, int column ){
        /*
         * Añade ficha tipo rey
         */
        tipo = "configuracion";
        fila = row;
        column = columna;

    }

    public void makeVisible(){
        /*
         * hace visible los tableros (configuracion y juego)
         */
        confi.drawboard();
        juego.drawboard();

    }

    public void add(int fichas ){
        /*
         * Añade la cantidad de fichas que tendrá cada jugador
         */
        tipo = "configuracion";
        if (itsOk==true){

            numero = fichas;
            fichasTablero();
        }
        else{

            JOptionPane.showMessageDialog(null,"Esta en juego por lo que no puede agregar fichas","ERROR!",JOptionPane.ERROR_MESSAGE);
            
        }
    }

    private void fichasUno(int fila , int columna, String color){
        /*
         * Pocisiona fichas jugador 1
         */

        jugadorUno[fila][columna]= new Circle(columna*20+22, fila*20+22, color);
        jugadorUno[fila][columna].makeVisible();

    }

    private void fichasDos(int fila , int columna, String color){
        /*
         * Pocisiona fichas jugador 2
         */
        jugadorDos[fila][columna] = new Circle(columna*20+22, fila*20+22,color);
        jugadorDos[fila][columna].makeVisible();

    }

    public void removeJugadorUno(int fila, int columna){
        /*
         * elimina fichas jugador 1
         */
        tipo = "configuracion";
        if (itsOk==true){
            this.fila = fila;
            this.columna = columna;
            int Xposition = 0;
            int Yposition = 0;
            for (int i=0;i<8;i++){

                for(int j=0; j<8;j++){

                    if (i == this.fila && j == this.columna ){
                        jugadorUno[i][j].makeInvisible();
                        jugadorUno[i][j].moveHorizontal(Xposition);
                        jugadorUno[i][j].moveVertical(Yposition);

                    }
                    Xposition+=20;

                }
                Yposition+=20;
                Xposition = 0;

            }
        }
        else{
            JOptionPane.showMessageDialog(null,"Esta en juego por lo que no puede remover fichas","ERROR!",JOptionPane.ERROR_MESSAGE);
            
        }
    }

    public void removeJugadorDos(int fila, int columna){
        /*
         * elimina fichas jugador 2
         */
        tipo = "configuracion";
        if (itsOk==true){
            this.fila = fila;
            this.columna = columna;
            int Xposition = 0;
            int Yposition = 0;
            for (int i=0;i<8;i++){
                for(int j=0; j<8;j++){

                    if (i == this.fila && j == this.columna ){
                        jugadorDos[i][j].makeInvisible();
                        jugadorDos[i][j].moveHorizontal(Xposition);
                        jugadorDos[i][j].moveVertical(Yposition);

                    }

                    Xposition+=20;

                }
                Yposition+=20;
                Xposition = 0;

            }
        }
        else{

            JOptionPane.showMessageDialog(null,"Esta en juego por lo que no puede remover fichas","ERROR!",JOptionPane.ERROR_MESSAGE);
            
        }
    }

    private void fichasTablero(){
        /*
         * Pide información acerca de las fichas de los jugadores
         */
        Scanner scan = new Scanner(System.in);
        int vecesQueSerRepite = (numero*2);
        System.out.println("Jugador Uno, ¿Qué color desea sus fichas?");
        String colorUno= scan.nextLine();
        this.colorUno = colorUno; 
        System.out.println("Jugador Dos, ¿Qué color desea sus fichas?");
        String colorDos= scan.nextLine();
        this.colorDos = colorDos; 
        for(int i=1;i<=vecesQueSerRepite;i++){

            if (i<=numero ){
                System.out.println("Jugador Uno.");
                System.out.println("Escriba el numero de fila (0-7), después número de columna (0-7)");
                System.out.println("Recuerde: sus fichas deben estra ubicadas TODAS sobre el mismo color en el tablero");    
                int filaUno = Integer.parseInt(scan.nextLine());
                int columnaUno = Integer.parseInt(scan.nextLine());

                fichasUno(filaUno,columnaUno,colorUno);
            }
            else{
                System.out.println("Jugador Dos.");
                System.out.println("Escriba el numero de fila (0-7), después número de columna (0-7)");
                System.out.println("Recuerde: sus fichas deben estra ubicadas TODAS sobre el mismo color en el tablero"); 
                int filaDos = Integer.parseInt(scan.nextLine());
                int columnaDos = Integer.parseInt(scan.nextLine());

                fichasDos(filaDos,columnaDos,colorDos);

            }

        }

    }

    public void select (int fila, int columna){
        /*
         * selecciona una ficha
         */
        tipo = "juego";
        
        if (itsOk==false){
            this.fila = fila;
            this.columna = columna;
            jugadorUno[fila][columna].changeColor("yellow");
        }
        else{
            JOptionPane.showMessageDialog(null,"Esta en configuracion por lo que no puede seleccionar fichas","ERROR!",JOptionPane.ERROR_MESSAGE);
            
        }
    }

    public void moveJugadorUno(String movimiento){
        /*
         * mueve la ficha seleccionada del jugador uno
         */
        tipo = "juego";
        if (itsOk==false){
            if (movimiento == "derecha"){
                jugadorUno[fila][columna].moveDiagonal(20,20,"");
                jugadorUno[fila][columna] = null;
                jugadorUno[fila][columna] = jugadorUno[fila+1][columna+1];
    
            }
            else if(movimiento == "izquierda"){
                jugadorUno[fila][columna].moveDiagonal(-20,20,"");
                jugadorUno[fila][columna].makeVisible();
    
            }
        }
        else{
            JOptionPane.showMessageDialog(null,"Esta en configuracion por lo que no puede mover fichas","ERROR!",JOptionPane.ERROR_MESSAGE);
            
        }
    }

    public boolean ok(){
        /*
         * Verifica si el anterior método fue hecho correctamente
         */
        boolean x = game(itsOk);
        boolean y = board(itsOk);
        if (tipo=="juego"){
            return(x);
        
        
        }
        else{
            return(y);
        
        }
    }
    
    private boolean game(boolean juego){
        juego=itsOk;
        if (juego== false){
            return (true);
        }
        else{
            return (false);
        }
    
    }
    
    private boolean board(boolean tablero){
        tablero = itsOk;
        if (tablero == true){
            return true;
        }
        else{
            return false;
        }
    }
    public void swap(){
        /*
         * Permite cambiar de tablero de configuracion a tablero de juego. 
         * Permite cambiar de tablero de juego a tablero de configuracion . 
         */
        if (itsOk== true){
            itsOk = false;
        }
        else{
            itsOk = true;
        }
        
    
    }
}

/**
 * An example of a method - replace this comment with your own
 *
 * @param  y  a sample parameter for a method
 * @return    the sum of x and y
 */

