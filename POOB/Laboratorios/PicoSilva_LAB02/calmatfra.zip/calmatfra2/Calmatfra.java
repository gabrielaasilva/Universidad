/** Calculadora.java
 * Representa una calculadora de matrices de fraccionarios
 * @author ESCUELA 2018-01
 */

import java.util.HashMap;
import java.util.ArrayList;
public class Calmatfra{

    private HashMap<String, int[][][]> diccionario;
    //Consultar en el API Java la clase HashMap
    private int[][][] matrizGlobal;
    private HashMap<String, Matriz> variables;
    private static ArrayList<Fraccionario> fraction;
    private ArrayList<Integer>toMatriz;
    private ArrayList<Fraccionario> memoria1 = new ArrayList<Fraccionario>();
    /**
     * Inicializa el HashMap
     */   
    public Calmatfra(){
        diccionario = new HashMap<String, int[][][]>();
    }

    /** Asigna una matriz a una variable
     * @param variable 
     * @param matriz
     */
    public void asigne(String variable, int [][][] matriz){
        diccionario.put(variable,matriz); 
    }
    // Los operadores binarios : + (suma), - (resta), . (multiplique elemento a elemento), * (multiplique matricial)
    /**Opera las matrices que se pongan y se agregara a otra
     * @param respuesta
     * @param operando1
     * @param operando2
     * @param operacion 
     */
    public void opere(String respuesta, String operando1, char operacion, String operando2){
        int[][][] matriz = diccionario.get(operando1);
        int[][][] matriz2 = diccionario.get(operando2);
        convierteFracciones(matriz);
        convierteFraccionesDos(matriz2);
        if (operacion=='+'){
            Fraccionario.sume(memoria1.get(0));
            Fraccionario.sume(memoria1.get(1));
        }
        else {
            Fraccionario.reste(memoria1.get(0));
            Fraccionario.reste(memoria1.get(1));
        }

    }

    /** Consulta una variable 
     * @param variable
     * @return String
     */
    public String consulta(String variable){   
        int [][][] matriz = diccionario.get(variable);
        convertir(matriz);
        String x = toMatriz.get(0)+"/"+toMatriz.get(1);
        String y = toMatriz.get(2)+"/"+toMatriz.get(3);
        return x+","+y ;
    }

    public boolean ok(){
        return false;
    }

    /** convierte cada posicion de la matriz en un String
     * @param matriz
     */
    private ArrayList convertir(int[][][]matriz){
        toMatriz = new ArrayList<Integer>(); 
        int numero = 0;
        for (int[][] i:matriz){
            for (int[] j:i){
                for(int k:j){
                    toMatriz.add(k);
                }
            }            
        }
        return toMatriz;
    }

    private void convierteFracciones(int[][][] matrix){
        fraction = new ArrayList();    
        int numerador;
        int denominador;
        Fraccionario valor;
        for(int[][] i:matrix){
            for(int[] j:i){
                numerador =0;
                denominador = 0;
                for(int k:j){                    
                    if (numerador == 0){
                        numerador = k; 
                    }
                    else {
                        denominador = k;
                    }                    
                }
                valor= new Fraccionario(numerador,denominador);                
                fraction.add(valor);                
            }
        }     
     }

    private void convierteFraccionesDos(int[][][] matriz){        
        int numerador;
        int denominador;
        Fraccionario valor;
        for(int[][] i:matriz){
            for(int[] j:i){
                numerador =0;
                denominador = 0;
                for(int k:j){                    
                    if (numerador == 0){
                        numerador = k;  

                    }
                    else {
                        denominador = k;

                    }                    
                }
                valor= new Fraccionario(numerador,denominador);
                memoria1.add(valor);
            }
        }    
    }

}

