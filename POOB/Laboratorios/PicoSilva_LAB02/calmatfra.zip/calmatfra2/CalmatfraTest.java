

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class CalmatfraTest
{
    @Test
    public void deberiaErrar(){
        fail();
    
    }
}
