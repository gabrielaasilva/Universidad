    
    /**
     * Write a description of class Juego here.
     * 
     * @author (your name) 
     * @version (a version number or a date)
     */
public class Juego
    {

    private int [][] matrix=
        {{0,1,0,1,0,1,0,1},
            {1,0,1,0,1,0,1,0},
            {0,1,0,1,0,1,0,1},
            {1,0,1,0,1,0,1,0},
            {0,1,0,1,0,1,0,1},
            {1,0,1,0,1,0,1,0},
            {0,1,0,1,0,1,0,1},
            {1,0,1,0,1,0,1,0}};
    private int Xposition;
    private int Yposition;
    private Rectangle[][] tablero;
    /**
     * Constructor for objects of class Juego
     */
    public Juego(int Xposition)
    {
        this.Xposition = Xposition;
    
  
       
        
    }
    
    public void drawboard(){
        /*
         * Permite crear los tableros
         */
        tablero = new Rectangle[8][8];
        
        int conta = 0;
        
        for(int i=0;i<8;i++){

            for (int j=0; j<8; j++){
            tablero[i][j] = new Rectangle();    
                if (matrix[i][j]==1){
                
                
                tablero[i][j].changeColor("black");
                tablero[i][j].makeVisible();    
                tablero[i][j].moveHorizontal(Xposition+20*j);
                tablero[i][j].moveVertical(Yposition+20*i);
               
                 
                
    
            }
            else if(matrix[i][j]==0){
            tablero[i][j].changeColor("white");
            tablero[i][j].makeVisible();
            
            }
               
                
                   
            }  
        
         
    }
    }
    
    
    

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    
}
